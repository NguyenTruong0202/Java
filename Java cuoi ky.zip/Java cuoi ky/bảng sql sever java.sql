﻿USE QuanLyChuyenDi;
GO 
CREATE TABLE DIADIEM (
    MADD INT PRIMARY KEY,        -- Mã địa điểm (Khóa chính)
    TENDD NVARCHAR(100)          -- Tên địa điểm
);
CREATE TABLE XE (
    BIENSO NVARCHAR(20) PRIMARY KEY,  -- Biển số xe (Khóa chính)
    KHTD NVARCHAR(100)               -- Khách hàng sử dụng dịch vụ
);
CREATE TABLE HUONGDV (
    MAHDV INT PRIMARY KEY,            -- Mã hướng dẫn viên (Khóa chính)
    HTHDV NVARCHAR(100),              -- Họ tên hướng dẫn viên
    DCHDV NVARCHAR(255)               -- Địa chỉ hướng dẫn viên
);
CREATE TABLE KHACH (
    MACD INT PRIMARY KEY,             -- Mã khách hàng (Khóa chính, có thể là mã chuyến đi)
    HTKH NVARCHAR(100),               -- Họ tên khách hàng
    TUOI INT,                          -- Tuổi khách hàng
    DCKH NVARCHAR(255),               -- Địa chỉ khách hàng
    DTKH NVARCHAR(20)                 -- Số điện thoại khách hàng
);
CREATE TABLE CHUYENDI (
    MACD INT PRIMARY KEY,              -- Mã chuyến đi (Khóa chính)
    TENCD NVARCHAR(100),               -- Tên chuyến đi
    NGKH DATE,                         -- Ngày khởi hành
    NGKT DATE,                         -- Ngày kết thúc
    KHDK INT,                          -- Khách hàng đăng ký (Liên kết với bảng KHACH)
    BIENSO NVARCHAR(20),               -- Biển số xe (Liên kết với bảng XE)
    MAHDV INT,                         -- Mã hướng dẫn viên (Liên kết với bảng HUONGDV)
    
    FOREIGN KEY (MACD) REFERENCES KHACH(MACD),  -- Khóa ngoại liên kết với bảng KHACH
    FOREIGN KEY (BIENSO) REFERENCES XE(BIENSO),  -- Khóa ngoại liên kết với bảng XE
    FOREIGN KEY (MAHDV) REFERENCES HUONGDV(MAHDV) -- Khóa ngoại liên kết với bảng HUONGDV
);
CREATE TABLE CTIETCD (
    MACD INT,                          -- Mã chuyến đi
    MADD INT,                          -- Mã địa điểm
    SNLUU INT,                         -- Số lượng lưu trú
    PRIMARY KEY (MACD, MADD),          -- Khóa chính kết hợp giữa MACD và MADD
    
    FOREIGN KEY (MACD) REFERENCES CHUYENDI(MACD),  -- Khóa ngoại liên kết với bảng CHUYENDI
    FOREIGN KEY (MADD) REFERENCES DIADIEM(MADD)    -- Khóa ngoại liên kết với bảng DIADIEM
);
