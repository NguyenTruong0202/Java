import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class frmkhach {
    public static void main(String[] args) {
        // Tạo frame chính
        JFrame frame = new JFrame("Hệ thống Quản lý");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Tiêu đề
        JLabel titleLabel = new JLabel("KHÁCH HÀNG", SwingConstants.CENTER);
        titleLabel.setBounds(50, 10, 700, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        frame.add(titleLabel);

        // Thanh tìm kiếm
        JLabel searchLabel = new JLabel("Tìm kiếm mã chuyến đi:");
        searchLabel.setBounds(50, 260, 150, 25); // Điều chỉnh Y để nằm dưới tiêu đề
        JTextField searchField = new JTextField();
        searchField.setBounds(200, 260, 200, 25); // Cùng hàng với searchLabel
        JButton searchButton = new JButton("Tìm kiếm");
        searchButton.setBounds(420, 260, 100, 25); // Đặt sau searchField

        frame.add(searchLabel);
        frame.add(searchField);
        frame.add(searchButton);

        // Bảng dữ liệu
        String[] columnNames = {"Mã khách hàng", "Họ tên khách hàng", "Tuổi", "Địa chỉ khách hàng", "Điện thoại khách hàng"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);

        // Panel chứa bảng
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 50, 700, 200);
        frame.add(scrollPane);

        // Form nhập liệu
        JPanel formPanel = new JPanel(null);
        formPanel.setBounds(50, 300, 700, 200); // Điều chỉnh để nằm dưới thanh tìm kiếm
        formPanel.setBorder(BorderFactory.createTitledBorder("Thông tin khách hàng"));

        // Các nhãn và trường nhập liệu
        JLabel idLabel = new JLabel("Mã chuyến đi:");
        idLabel.setBounds(20, 30, 120, 25);
        JTextField idField = new JTextField();
        idField.setBounds(150, 30, 200, 25);

        JLabel nameLabel = new JLabel("Họ tên khách hàng:");
        nameLabel.setBounds(20, 70, 120, 25);
        JTextField nameField = new JTextField();
        nameField.setBounds(150, 70, 200, 25);

        JLabel ageLabel = new JLabel("Tuổi:");
        ageLabel.setBounds(400, 30, 120, 25);
        JTextField ageField = new JTextField();
        ageField.setBounds(500, 30, 150, 25);

        JLabel addressLabel = new JLabel("Địa chỉ khách hàng:");
        addressLabel.setBounds(20, 110, 120, 25);
        JTextField addressField = new JTextField();
        addressField.setBounds(150, 110, 200, 25);

        JLabel phoneLabel = new JLabel("Điện thoại khách hàng:");
        phoneLabel.setBounds(400, 70, 150, 25);
        JTextField phoneField = new JTextField();
        phoneField.setBounds(500, 70, 150, 25);

        formPanel.add(idLabel);
        formPanel.add(idField);
        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(ageLabel);
        formPanel.add(ageField);
        formPanel.add(addressLabel);
        formPanel.add(addressField);
        formPanel.add(phoneLabel);
        formPanel.add(phoneField);

        frame.add(formPanel);

        // Các nút chức năng
        JButton addButton = new JButton("Thêm mới");
        addButton.setBounds(100, 520, 120, 30);
        JButton updateButton = new JButton("Cập nhật");
        updateButton.setBounds(250, 520, 120, 30);
        JButton deleteButton = new JButton("Xóa");
        deleteButton.setBounds(400, 520, 120, 30);
        JButton clearButton = new JButton("Làm mới");
        clearButton.setBounds(550, 520, 120, 30);

        frame.add(addButton);
        frame.add(updateButton);
        frame.add(deleteButton);
        frame.add(clearButton);

        // Xử lý nút tìm kiếm
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchTerm = searchField.getText().trim();
                if (!searchTerm.isEmpty()) {
                    searchCustomerById(tableModel, searchTerm);
                } else {
                    fetchDataFromDatabase(tableModel);
                }
            }
        });

        // Xử lý nút thêm mới
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();
                String name = nameField.getText();
                String age = ageField.getText();
                String address = addressField.getText();
                String phone = phoneField.getText();

                if (id.isEmpty() || name.isEmpty() || age.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Vui lòng điền đầy đủ thông tin!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else {
                    tableModel.addRow(new Object[]{id, name, age, address, phone});
                    JOptionPane.showMessageDialog(frame, "Thêm mới thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Xử lý nút cập nhật
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    tableModel.setValueAt(idField.getText(), selectedRow, 0);
                    tableModel.setValueAt(nameField.getText(), selectedRow, 1);
                    tableModel.setValueAt(ageField.getText(), selectedRow, 2);
                    tableModel.setValueAt(addressField.getText(), selectedRow, 3);
                    tableModel.setValueAt(phoneField.getText(), selectedRow, 4);
                    JOptionPane.showMessageDialog(frame, "Cập nhật thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Vui lòng chọn hàng cần cập nhật!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Xử lý nút xóa
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(frame, "Xóa thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Vui lòng chọn hàng cần xóa!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Xử lý nút làm mới
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                idField.setText("");
                nameField.setText("");
                ageField.setText("");
                addressField.setText("");
                phoneField.setText("");
            }
        });

        // Fetch data from SQL Server
        fetchDataFromDatabase(tableModel);

        // Hiển thị frame
        frame.setVisible(true);
    }

    // Method to fetch data from SQL Server
    private static void fetchDataFromDatabase(DefaultTableModel tableModel) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyChuyenDi;trustServerCertificate=true";
        String username = "sa";
        String password = "thienan0338275401";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
            String query = "SELECT * FROM KHACH";
            resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("MACD");
                String name = resultSet.getString("HTKH");
                String age = resultSet.getString("TUOI");
                String address = resultSet.getString("DCKH");
                String phone = resultSet.getString("DTKH");

                tableModel.addRow(new Object[]{id, name, age, address, phone});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi kết nối cơ sở dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to search for a customer by ID
    private static void searchCustomerById(DefaultTableModel tableModel, String searchTerm) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyChuyenDi;trustServerCertificate=true";
        String username = "sa";
        String password = "thienan0338275401";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
            String query = "SELECT * FROM KHACH WHERE MACD = '" + searchTerm + "'";
            resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("MACD");
                String name = resultSet.getString("HTKH");
                String age = resultSet.getString("TUOI");
                String address = resultSet.getString("DCKH");
                String phone = resultSet.getString("DTKH");

                tableModel.addRow(new Object[]{id, name, age, address, phone});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi khi tìm kiếm dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}