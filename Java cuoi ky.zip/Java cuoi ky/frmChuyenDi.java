import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class frmChuyenDi{
    public static void main(String[] args) {
        JFrame frame = new JFrame("Hệ thống Quản lý Chuyến Đi");
        frame.setSize(900, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel titleLabel = new JLabel("CHUYẾN ĐI", SwingConstants.CENTER);
        titleLabel.setBounds(50, 10, 800, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        frame.add(titleLabel);

        JLabel searchLabel = new JLabel("Tìm kiếm mã chuyến đi:");
        searchLabel.setBounds(50, 260, 150, 25);
        JTextField searchField = new JTextField();
        searchField.setBounds(200, 260, 200, 25);
        JButton searchButton = new JButton("Tìm kiếm");
        searchButton.setBounds(420, 260, 100, 25);

        frame.add(searchLabel);
        frame.add(searchField);
        frame.add(searchButton);

        // Định nghĩa cột
        String[] columnNames = {"Mã chuyến đi", "Tên chuyến đi", "Ngày khởi hành", "Ngày kết thúc", "Biển số", "Mã HDV", "Khách hàng dự kiến"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 50, 800, 200);
        frame.add(scrollPane);

        JPanel formPanel = new JPanel(null);
        formPanel.setBounds(50, 300, 800, 200);
        formPanel.setBorder(BorderFactory.createTitledBorder("Thông tin chuyến đi"));

        JLabel idLabel = new JLabel("Mã chuyến đi:");
        idLabel.setBounds(20, 30, 120, 25);
        JTextField idField = new JTextField();
        idField.setBounds(150, 30, 200, 25);

        JLabel nameLabel = new JLabel("Tên chuyến đi:");
        nameLabel.setBounds(20, 70, 120, 25);
        JTextField nameField = new JTextField();
        nameField.setBounds(150, 70, 200, 25);

        JLabel startDateLabel = new JLabel("Ngày khởi hành:");
        startDateLabel.setBounds(400, 30, 120, 25);
        JTextField startDateField = new JTextField();
        startDateField.setBounds(550, 30, 200, 25);

        JLabel endDateLabel = new JLabel("Ngày kết thúc:");
        endDateLabel.setBounds(20, 110, 120, 25);
        JTextField endDateField = new JTextField();
        endDateField.setBounds(150, 110, 200, 25);

        JLabel plateLabel = new JLabel("Biển số:");
        plateLabel.setBounds(400, 70, 120, 25);
        JTextField plateField = new JTextField();
        plateField.setBounds(550, 70, 200, 25);

        JLabel guideIdLabel = new JLabel("Mã HDV:");
        guideIdLabel.setBounds(400, 110, 120, 25);
        JTextField guideIdField = new JTextField();
        guideIdField.setBounds(550, 110, 200, 25);

        JLabel customersLabel = new JLabel("Khách hàng dự kiến:");
        customersLabel.setBounds(20, 150, 150, 25);
        JTextField customersField = new JTextField();
        customersField.setBounds(150, 150, 600, 25);

        formPanel.add(idLabel);
        formPanel.add(idField);
        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(startDateLabel);
        formPanel.add(startDateField);
        formPanel.add(endDateLabel);
        formPanel.add(endDateField);
        formPanel.add(plateLabel);
        formPanel.add(plateField);
        formPanel.add(guideIdLabel);
        formPanel.add(guideIdField);
        formPanel.add(customersLabel);
        formPanel.add(customersField);

        frame.add(formPanel);

        JButton addButton = new JButton("Thêm mới");
        addButton.setBounds(100, 520, 120, 30);
        JButton updateButton = new JButton("Cập nhật");
        updateButton.setBounds(250, 520, 120, 30);
        JButton deleteButton = new JButton("Xóa");
        deleteButton.setBounds(400, 520, 120, 30);
        JButton clearButton = new JButton("Làm mới");
        clearButton.setBounds(550, 520, 120, 30);

        frame.add(addButton);
        frame.add(updateButton);
        frame.add(deleteButton);
        frame.add(clearButton);

        // Nút tìm kiếm
        searchButton.addActionListener(e -> {
            String searchTerm = searchField.getText().trim();
            if (!searchTerm.isEmpty()) {
                searchTripById(tableModel, searchTerm);
            } else {
                fetchDataFromDatabase(tableModel);
            }
        });

        // Tải dữ liệu từ cơ sở dữ liệu
        fetchDataFromDatabase(tableModel);

        frame.setVisible(true);
    }

    private static void fetchDataFromDatabase(DefaultTableModel tableModel) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyChuyenDi;trustServerCertificate=true";
        String username = "sa";
        String password = "thienan0338275401";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            String query = "SELECT * FROM CHUYENDI";
            ResultSet resultSet = statement.executeQuery(query);
            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("MACD");
                String name = resultSet.getString("TENCD");
                String startDate = resultSet.getString("NGKH");
                String endDate = resultSet.getString("NGKT");
                String customers = resultSet.getString("KHDK");
                String plate = resultSet.getString("BIENSO");
                String guideId = resultSet.getString("MAHDV");
                
                tableModel.addRow(new Object[]{id, name, startDate, endDate, customers ,plate, guideId});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi kết nối cơ sở dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void searchTripById(DefaultTableModel tableModel, String searchTerm) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyChuyenDi;trustServerCertificate=true";
        String username = "sa";
        String password = "thienan0338275401";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CHUYENDI WHERE MACD = ?")) {

            preparedStatement.setString(1, searchTerm);
            ResultSet resultSet = preparedStatement.executeQuery();
            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("MACD");
                String name = resultSet.getString("TENCD");
                String startDate = resultSet.getString("NGKH");
                String endDate = resultSet.getString("NGKT");
                String customers = resultSet.getString("KHDK");
                String plate = resultSet.getString("BIENSO");
                String guideId = resultSet.getString("MAHDV");
                

                tableModel.addRow(new Object[]{id, name, startDate, endDate,customers, plate, guideId });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi khi tìm kiếm dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
