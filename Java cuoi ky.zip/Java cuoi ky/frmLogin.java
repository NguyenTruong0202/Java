import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class frmLogin {
    // HashMap để lưu thông tin tài khoản
    private static HashMap<String, String> userDatabase = new HashMap<>();

    public static void main(String[] args) {
        // Tạo frame chính
        JFrame frame = new JFrame("System Manager Travel");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Tiêu đề
        JLabel titleLabel = new JLabel("QUẢN LÝ CÔNG TY DU LỊCH ", SwingConstants.CENTER);
        titleLabel.setBounds(50, 20, 500, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        frame.add(titleLabel);

        // Tạo menu bar
        JMenuBar menuBar = new JMenuBar();

        // Menu File
        JMenu fileMenu = new JMenu("File");
        JMenuItem openItem = new JMenuItem("Open");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem exitItem = new JMenuItem("Exit");

        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // Menu Module
        JMenu moduleMenu = new JMenu("Module");
        JMenuItem settingsItem = new JMenuItem("Settings");
        JMenuItem toolsItem = new JMenuItem("Tools");

        moduleMenu.add(settingsItem);
        moduleMenu.add(toolsItem);

        // Menu Help
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        JMenuItem supportItem = new JMenuItem("Support");

        helpMenu.add(aboutItem);
        helpMenu.add(supportItem);

        menuBar.add(fileMenu);
        menuBar.add(moduleMenu);
        menuBar.add(helpMenu);

        frame.setJMenuBar(menuBar);

        // Panel đăng nhập
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(null);
        loginPanel.setBounds(200, 100, 300, 150);
        loginPanel.setBorder(BorderFactory.createTitledBorder("ĐĂNG NHẬP HỆ THỐNG"));

        JLabel userLabel = new JLabel("Tên đăng nhập:");
        userLabel.setBounds(20, 30, 100, 25);
        JTextField userField = new JTextField();
        userField.setBounds(130, 30, 150, 25);
        loginPanel.add(userLabel);
        loginPanel.add(userField);

        JLabel passwordLabel = new JLabel("Mật khẩu:");
        passwordLabel.setBounds(20, 70, 100, 25);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(130, 70, 150, 25);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);

        JButton loginButton = new JButton("Đăng nhập");
        loginButton.setBounds(50, 110, 100, 25);
        JButton exitButton = new JButton("Thoát");
        exitButton.setBounds(160, 110, 100, 25);
        loginPanel.add(loginButton);
        loginPanel.add(exitButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passwordField.getPassword());

                // Kiểm tra thông tin đăng nhập
                if (userDatabase.containsKey(username) && userDatabase.get(username).equals(password)) {
                    JOptionPane.showMessageDialog(frame, "Đăng nhập thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose(); 
                    SwingUtilities.invokeLater(() -> {
                new MainForm().setVisible(true);
                  });
                } else {
                    JOptionPane.showMessageDialog(frame, "Thông tin đăng nhập không chính xác!", "Thông báo", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        exitButton.addActionListener(e -> System.exit(0));

        frame.add(loginPanel);

        // Các nút khác
        JButton signUpButton = new JButton("Đăng Ký");
        signUpButton.setBounds(50, 140, 100, 25);
        frame.add(signUpButton);

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSignUpForm();
            }
        });

        frame.setVisible(true);
    }

    private static void showSignUpForm() {
        JFrame signUpFrame = new JFrame("Đăng ký tài khoản");
        signUpFrame.setSize(400, 400);
        signUpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        signUpFrame.setLayout(null);

        JLabel usernameLabel = new JLabel("Tên đăng nhập (*)");
        usernameLabel.setBounds(50, 50, 120, 25);
        JTextField usernameField = new JTextField();
        usernameField.setBounds(170, 50, 200, 25);
        signUpFrame.add(usernameLabel);
        signUpFrame.add(usernameField);

        JLabel passwordLabel = new JLabel("Mật khẩu (*)");
        passwordLabel.setBounds(50, 100, 120, 25);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(170, 100, 200, 25);
        signUpFrame.add(passwordLabel);
        signUpFrame.add(passwordField);

        JLabel confirmPasswordLabel = new JLabel("Xác nhận mật khẩu (*)");
        confirmPasswordLabel.setBounds(50, 150, 150, 25);
        JPasswordField confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(170, 150, 200, 25);
        signUpFrame.add(confirmPasswordLabel);
        signUpFrame.add(confirmPasswordField);

        JButton registerButton = new JButton("Đăng Ký");
        registerButton.setBounds(150, 250, 100, 40);
        signUpFrame.add(registerButton);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());

                if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(signUpFrame, "Vui lòng điền đầy đủ thông tin!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(signUpFrame, "Mật khẩu không khớp!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else if (userDatabase.containsKey(username)) {
                    JOptionPane.showMessageDialog(signUpFrame, "Tên đăng nhập này đã được sử dụng!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else {
                    userDatabase.put(username, password);
                    JOptionPane.showMessageDialog(signUpFrame, "Đăng ký thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    signUpFrame.dispose();
                }
            }
        });

        signUpFrame.setVisible(true);
    }
}
