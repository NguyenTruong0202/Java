import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class frmctchuyendi {
    public static void main(String[] args) {
        // Tạo frame chính
        JFrame frame = new JFrame("Hệ thống Quản lý");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Tiêu đề
        JLabel titleLabel = new JLabel("CHI TIẾT CHUYẾN ĐI", SwingConstants.CENTER);
        titleLabel.setBounds(50, 10, 700, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        frame.add(titleLabel);

        // Thanh tìm kiếm
        JLabel searchLabel = new JLabel("Tìm kiếm mã chuyến đi:");
        searchLabel.setBounds(50, 260, 180, 25);
        JTextField searchField = new JTextField();
        searchField.setBounds(200, 260, 200, 25);
        JButton searchButton = new JButton("Tìm kiếm");
        searchButton.setBounds(420, 260, 100, 25);

        frame.add(searchLabel);
        frame.add(searchField);
        frame.add(searchButton);

        // Bảng dữ liệu
        String[] columnNames = {"Mã chuyến đi", "Mã địa điểm", "Số ngày lưu"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);

        // Panel chứa bảng
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 50, 700, 200);
        frame.add(scrollPane);

        // Form nhập liệu
        JPanel formPanel = new JPanel(null);
        formPanel.setBounds(50, 300, 700, 200); // Điều chỉnh vị trí
        formPanel.setBorder(BorderFactory.createTitledBorder("Thông tin chuyến đi"));

        // Các nhãn và trường nhập liệu
        JLabel idLabel = new JLabel("Mã chuyến đi:");
        idLabel.setBounds(20, 30, 150, 25);
        JTextField idField = new JTextField();
        idField.setBounds(170, 30, 200, 25);

        JLabel locationLabel = new JLabel("Mã địa điểm:");
        locationLabel.setBounds(20, 70, 150, 25);
        JTextField locationField = new JTextField();
        locationField.setBounds(170, 70, 200, 25);

        JLabel daysLabel = new JLabel("Số ngày lưu:");
        daysLabel.setBounds(400, 30, 150, 25);
        JTextField daysField = new JTextField();
        daysField.setBounds(550, 30, 150, 25);

        formPanel.add(idLabel);
        formPanel.add(idField);
        formPanel.add(locationLabel);
        formPanel.add(locationField);
        formPanel.add(daysLabel);
        formPanel.add(daysField);

        frame.add(formPanel);

        // Các nút chức năng
        JButton addButton = new JButton("Thêm mới");
        addButton.setBounds(100, 520, 120, 30);
        JButton updateButton = new JButton("Cập nhật");
        updateButton.setBounds(250, 520, 120, 30);
        JButton deleteButton = new JButton("Xóa");
        deleteButton.setBounds(400, 520, 120, 30);
        JButton clearButton = new JButton("Làm mới");
        clearButton.setBounds(550, 520, 120, 30);

        frame.add(addButton);
        frame.add(updateButton);
        frame.add(deleteButton);
        frame.add(clearButton);

        // Xử lý nút tìm kiếm
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchTerm = searchField.getText().trim();
                if (!searchTerm.isEmpty()) {
                    searchTravelById(tableModel, searchTerm);
                } else {
                    fetchDataFromDatabase(tableModel);
                }
            }
        });

        // Xử lý nút thêm mới
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();
                String location = locationField.getText();
                String days = daysField.getText();

                if (id.isEmpty() || location.isEmpty() || days.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Vui lòng điền đầy đủ thông tin!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else {
                    tableModel.addRow(new Object[]{id, location, Integer.parseInt(days)});
                    JOptionPane.showMessageDialog(frame, "Thêm mới thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Xử lý nút cập nhật
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    tableModel.setValueAt(idField.getText(), selectedRow, 0);
                    tableModel.setValueAt(locationField.getText(), selectedRow, 1);
                    tableModel.setValueAt(daysField.getText(), selectedRow, 2);
                    JOptionPane.showMessageDialog(frame, "Cập nhật thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Vui lòng chọn hàng cần cập nhật!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Xử lý nút xóa
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(frame, "Xóa thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Vui lòng chọn hàng cần xóa!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Xử lý nút làm mới
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                idField.setText("");
                locationField.setText("");
                daysField.setText("");
            }
        });

        // Fetch data from SQL Server
        fetchDataFromDatabase(tableModel);

        // Hiển thị frame
        frame.setVisible(true);
    }

    // Method to fetch data from SQL Server
    private static void fetchDataFromDatabase(DefaultTableModel tableModel) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyChuyenDi;trustServerCertificate=true";
        String username = "sa";
        String password = "thienan0338275401";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
            String query = "SELECT * FROM CTIETCD";
            resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("MACD");
                String location = resultSet.getString("MADD");
                String days = resultSet.getString("SNLUU");

                tableModel.addRow(new Object[]{id, location, days});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi kết nối cơ sở dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to search for a travel by ID
    private static void searchTravelById(DefaultTableModel tableModel, String searchTerm) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyChuyenDi;trustServerCertificate=true";
        String username = "sa";
        String password = "thienan0338275401";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
            String query = "SELECT * FROM CTIETCD WHERE MACD = '" + searchTerm + "'";
            resultSet = statement.executeQuery(query);

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("MACD");
                String location = resultSet.getString("MADD");
                String days = resultSet.getString("SNLUU");

                tableModel.addRow(new Object[]{id, location, days});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Lỗi kết nối cơ sở dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
